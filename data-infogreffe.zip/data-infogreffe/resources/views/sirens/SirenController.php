<?php

namespace App\Http\Controllers;

use App\Card;

use Illuminate\Http\Request;

use  App\Http\Controllers\Controller;

class SirenController extends Controller
{
    public function index()
    {
        $ceva =Card::all();

        return view('cards.index',compact('cards'));
    }
    public  function  show( Card $card)
    {



        return view('sirens.show', compact ('card'));
    }
}
