<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
// use \GuzzleHttp\Client;

class MainController extends Controller
{

    public function mike(Request $request)
    {
        $test = Request::create('https://api.datainfogreffe.fr/api/v1/Entreprise/FicheIdentite/123456789?token=AXfBH56aWQcdCKRHkUAd9UcT1zsydYfQajOGeDfjmE3ztMBNbwWxxfu0xWi2', 'GET');
//        $bla = $test->json();
        return '<pre>' . var_export($test->getContent(), true) . '</pre>';
        return '<pre>' . var_export([
            // 'get_class' => get_class($test),
//                 'get_class_methods' => get_class_methods($test),
//                'json' => get_class($bla),
//                'json_methods' => get_class_methods($bla),
        ], true) . '</pre>';
    }

    /// My Function
    public function main()
    {
        /** @var \GuzzleHttp\Client $client */
        $client = new \GuzzleHttp\Client();

        $url = 'https://api.datainfogreffe.fr/api/v1/Entreprise/FicheIdentite/123456789?token=AXfBH56aWQcdCKRHkUAd9UcT1zsydYfQajOGeDfjmE3ztMBNbwWxxfu0xWi2';
        /** @var \GuzzleHttp\Psr7\Response $res */
        $res = $client->request('GET', $url);
        /** @var \GuzzleHttp\Psr7\Stream $resBody */
        $resBody = $res->getBody();
        $companyData = json_decode($resBody);
        return '<pre>'.print_r( $companyData, true).'</pre>';
    }
        //Close Class
}

