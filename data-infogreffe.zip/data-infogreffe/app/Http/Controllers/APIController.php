<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class APIController extends Controller
{

    public function mike(Request $request) {
        $test = Request::create('https://api.datainfogreffe.fr/api/v1/Entreprise/FicheIdentite/123456789?token=AXfBH56aWQcdCKRHkUAd9UcT1zsydYfQajOGeDfjmE3ztMBNbwWxxfu0xWi2', 'GET');
//        $bla = $test->json();
        return '<pre>'.var_export($test->getContent(), true).'</pre>';
        return '<pre>'.var_export([
                // 'get_class' => get_class($test),
//                 'get_class_methods' => get_class_methods($test),
//                'json' => get_class($bla),
//                'json_methods' => get_class_methods($bla),
            ], true).'</pre>';
    }

    public function register(Request $request)
    {
        $input = $request->all();
        $input['password'] = Hash::make($input['password']);
        User::create($input);
        return response()->json(['result'=>true]);
    }

    public function login(Request $request)
    {
        $input = $request->all();
        if (!$token = JWTAuth::attempt($input)) {
            return response()->json(['result' => 'wrong email or password.']);
        }
        return response()->json(['result' => $token]);
    }

    public function get_user_details(Request $request)
    {
        $input = $request->all();
        $user = JWTAuth::toUser($input['token']);
        return response()->json(['result' => $user]);
    }

}